## How to Use
1. Go to Dashboard
2. Select Chart Options (Line Chart, Bar Chart)
3. It will display the real-time visualization in 2 forms (Line and Bar)

## Toolsets Used
+ HTML
+ CSS
+ Javascript
+ jQuery
+ Bootstrap
+ D3.js
+ Angular 1.5.8
+ Node.js